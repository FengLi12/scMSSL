class _CONSTANTS:
    X_KEY = "X"
    BATCH_KEY = "batch_indices"
    LOCAL_L_MEAN_KEY = "local_l_mean"
    LOCAL_L_VAR_KEY = "local_l_var"
    LABELS_KEY = "labels"
    PROTEIN_EXP_KEY = "protein_expression"
    CAT_COVS_KEY = "cat_covs"
    CONT_COVS_KEY = "cont_covs"
